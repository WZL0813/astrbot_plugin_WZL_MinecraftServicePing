# astrbot_plugin_WZL_MinecraftServicePing

_✨MC服务器状态插件 ✨_  



@register("获取 Minecraft JE/BE 服务器 一系列信息", "WZL", "astrbot_plugin_WZL_MinecraftServicePing", "1.0.0", "https://github.com/WZL0813/astrbot_plugin_WZL_MinecraftServicePing")



## 🤝 介绍

基于astrbot的查询MineCraft服务器状态并返回图片的插件

## 📦 安装

- astrbot插件市场搜索astrbot_plugin_mcping，点击安装，等待完成即可。
- 或者可以直接克隆源码到插件文件夹：

```bash
# 克隆仓库到插件目录
cd /AstrBot/data/plugins
git clone https://github.com/WZL0813/astrbot_plugin_WZL_MinecraftServicePing

# 控制台重启AstrBot
```

## ⚙️ 配置

请在astrbot面板配置，插件管理 -> astrbot_plugin_WZL_MinecraftServicePing -> 操作 -> 插件配置

## 🐔 使用说明

## 指令

```bash
/mcp MC服务器地址  #举例:/mcp mcs.ryokuryuneko.top  

```



## 👥 贡献指南

- 🌟 Star 这个项目！（点右上角的星星，感谢支持！）
- 🐛 提交 Issue 报告问题
- 💡 提出新功能建议
- 🔧 提交 Pull Request 改进代码

## 📌 注意事项

- 理论上Java版服务器和基岩版服务器都支持
